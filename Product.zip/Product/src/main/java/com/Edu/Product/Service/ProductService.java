package com.Edu.Product.Service;

import com.Edu.Product.DTO.ProductDTO;

public interface ProductService {

	public ProductDTO Createproduct(ProductDTO prod);
}
