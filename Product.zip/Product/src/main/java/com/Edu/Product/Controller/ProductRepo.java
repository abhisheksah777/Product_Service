package com.Edu.Product.Controller;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Edu.Product.Entity.Product;

@EnableAutoConfiguration
public interface ProductRepo extends JpaRepository<Product, Integer> {

}
