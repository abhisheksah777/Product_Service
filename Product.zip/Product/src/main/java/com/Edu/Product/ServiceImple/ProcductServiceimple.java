package com.Edu.Product.ServiceImple;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Edu.Product.Controller.ProductRepo;
import com.Edu.Product.DTO.ProductDTO;
import com.Edu.Product.Entity.Product;
import com.Edu.Product.Service.ProductService;
import lombok.AllArgsConstructor;

@Service

@AllArgsConstructor
public class ProcductServiceimple implements ProductService {
	@Autowired
	ProductRepo productRepo;
	ModelMapper modelMapper = new ModelMapper();

	public ProductDTO Createproduct(ProductDTO prod) {
		Product product = modelMapper.map(prod, Product.class);
		Product productsave = productRepo.save(product);
		ProductDTO proddto = modelMapper.map(productsave, ProductDTO.class);
		return proddto;
	}

}
